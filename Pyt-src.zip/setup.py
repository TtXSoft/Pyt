from distutils.core import setup
from Cython.Build import cythonize
setup(
    name = 'Pyt',
    ext_modules = cythonize('pyt.pyx'),
)
