import sys
exec(open(sys.argv[1]).read())
